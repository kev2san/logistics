const express 	= require('express')
const modules    	= require('../controllers/modulesController')

const route 	= express.Router()


module.exports = route
